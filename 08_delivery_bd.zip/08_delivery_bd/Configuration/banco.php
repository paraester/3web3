<?php
$banco = [
    'driver' => 'mysql',
    'servidor' => 'localhost',
    'porta' => '3306',
    'banco' => 'pizzaria',
    'usuario' => 'root',
    'senha' => '123mudar',
];
