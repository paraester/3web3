<?php
require_once 'Configuration/geral.php';
require_once 'Framework/Loader.php';

$app = new \Framework\Aplicacao();
$app->rodar();
