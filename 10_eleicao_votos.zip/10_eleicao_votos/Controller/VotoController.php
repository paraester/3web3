<?php
namespace Controller;

use \Model\Candidato;

const VIEW_VOTO = APLICACAO_VIEW . 'votos/';

class VotoController
{
    public function index()
    {
        $candidatos = Candidato::all();
        require VIEW_VOTO . 'index.php';
    }

    public function update()
    {
        $candidato = Candidato::find($_POST['id']);
        $candidato->votar();
        $candidato->save();
        header('Location: ' . URL_RAIZ . 'votos');
        exit;
    }
}
