<?php
$banco = [
    'driver' => 'mysql',
    'servidor' => 'localhost',
    'porta' => '3306',
    'banco' => 'eleicao',
    'usuario' => 'root',
    'senha' => '123mudar',
];
