<?php
$salario = 5000;
$bonus = 1.5; // 50%
$total = $salario * $bonus;

echo "Total: R$ " . ($salario * $bonus) . "\n";
echo "Total: R$ " . $total . "\n";
echo "Total: R$ ", $total, "\n";
echo "Total: R$ $total\n";
