<?php
echo "Hello world!\n";
?>
