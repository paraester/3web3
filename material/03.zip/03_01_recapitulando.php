<?php
$fatorial = 5;
$resultado = 1;
for ($n = 1; $n <= $fatorial; $n++) {
    $resultado *= $n;
}
echo "O fatorial de $fatorial é $resultado.\n";
