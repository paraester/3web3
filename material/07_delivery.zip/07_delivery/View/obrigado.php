<!DOCTYPE html>
<html>
<head>
    <title>Pizzaria Delivery</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?= URL_CSS . 'bootstrap.min.css' ?>">
    <link rel="stylesheet" href="<?= URL_CSS . 'geral.css' ?>">

    <meta http-equiv="refresh" content="7;URL='<?= URL_RAIZ . 'cliente' ?>'" />
</head>
<body>
    <div class="center-block site">
        <h1 class="text-center">Obrigado pelo pedido!</h1>
        <h2>Você ser redirecionado em alguns instantes.</h2>
    </div>
</body>
</html>
