<?php
$banco = [
    'driver' => 'mysql',
    'servidor' => 'localhost',
    'porta' => '3306',
    'banco' => 'chat',
    'usuario' => 'root',
    'senha' => '123mudar',
];
